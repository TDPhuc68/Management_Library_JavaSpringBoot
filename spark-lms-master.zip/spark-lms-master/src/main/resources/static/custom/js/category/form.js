$(document).ready(function() {
	$('#gotoListBtn').on('click', function() {
		window.location = "/category/list";
	});
});