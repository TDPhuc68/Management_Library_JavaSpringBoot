package com.spark.lms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SparkLmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparkLmsApplication.class, args);
	}
	
}
