# spark-lms
Library Management System developed in Spring Boot.


#### What does it offer?
It allows user to manage Members, Categories, Books and Issueing Books.


### Setup project
#### Setup database
Project requires MySql database. The version of the database is prefered to be 8.0 or later
#### Setup code
Create a .war file of project and deploy it on a webserver like Apache tomcat.


### Login
for login you may use username as 'admin' and password as 'admin'.

